var HomeController = {

	getIndex: function(req, res) {
		res.render('home/index');
	},

	getTest: function(req, res) {
		
	}
}

module.exports = HomeController;