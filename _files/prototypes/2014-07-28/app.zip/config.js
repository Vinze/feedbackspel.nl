module.exports = {
	database: {
		host     : 'localhost',
		user     : 'root',
		password : 'usbw',
		database : 'feedbackspel.nl'
	},
	secret: 'fTTSl@LOWoWAP9%^U*AlT_PE^Mqhxk*A'
}