# Afstuderen Vincent Bremer

Enkele ideeën:

## Start CRM (afgekeurd)
Een zo simpel en basic CRM mogelijk maken welke door ieder leek op ieder device te gebruiken is.

### Doelgroep
- Startende ondernemers.
- ZZP'ers en freelancers.

### Doelstelling
- Relatiebeheer vereenvoudigen.
- Administratief werk uit handen nemen.
- Kostbare tijd besparen.
- Relaties effectiever van dienst zijn.

### Waarom?
- Er is vraag naar vanuit het bedrijfsleven.
- Bestaande oplossing zijn ontzettend uitgebreid.
- Een maatwerk CRM is erg duur om te laten ontwikkelen.

### Wat moet het minimaal kunnen?
- Relaties beheren
- Timeline achtig iets
- Statistieken
- Contactgegevens bijhouden
- Interacties toevoegen (logboek)
- Bestanden uploaden
- Uren registratie

### Mockup
![mockup](mockups/mockup_v1.00.png)

## Freez.it Inventory
Herschrijven van een bestaand CRM naar een nieuw framework.

## Online feedback spel
Reflecteren en feedback geven/ontvangen door een spel wat je via de webbrowser kan spelen.

## Projectmanagement tool
Leek me een leuk idee, maar er bestaan al veel van dit soort systemen.
