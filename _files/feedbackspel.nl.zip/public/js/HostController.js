app.controller('HostController', function($scope, socket) {

});