<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Feedbackspel.nl</title>
		{{ HTML::style('css/base.css') }}
		{{ HTML::style('css/website.css') }}
		{{ HTML::style('css/font-awesome.min.css') }}
		@yield('head')
	</head>
	<body>
		<div class="content">
			@yield('content')
		</div>
	</body>
	<script type="text/javascript">
		var base_url = "{{ url('/') }}";
	</script>
	{{ HTML::script('js/libs/zepto.min.js') }}
	@yield('scripts')
</html>