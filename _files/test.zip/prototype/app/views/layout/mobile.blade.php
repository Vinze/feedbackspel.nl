<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Feedbackspel.nl</title>
		<meta name="viewport" content="width=device-width, user-scalable=no">
		{{ HTML::style('css/base.css') }}
		{{ HTML::style('css/mobile.css') }}
		{{ HTML::style('css/font-awesome.min.css') }}
		@yield('head')
	</head>
	<body>
		<div class="content">
			@yield('content')
		</div>
	</body>
	<script type="text/javascript">
		var base_url = "{{ url('/') }}";
	</script>
	{{ HTML::script('js/libs/zepto.min.js') }}
	@yield('scripts')
</html>