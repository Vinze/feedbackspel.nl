@extends('layout.base')
@section('content')
	<h1>Inloggen</h1>
	{{ HTML::flash() }}
	{{ Form::open() }}
		<div class="fg">
			<div class="label">{{ Form::label('email', 'E-mail adres:') }}</div>
			<div class="field">{{ Form::text('email', 'vbremer89@gmail.com') }}</div>
		</div>
		<div class="fg">
			<div class="label">{{ Form::label('password', 'Wachtwoord:') }}</div>
			<div class="field">{{ Form::password('password') }}</div>
		</div>
		<div class="fg">
			<div class="label">{{ Form::label('remember_me', 'Onthoud mij:') }}</div>
			<div class="field"><label>{{ Form::checkbox('remember_me') }} Ja</label>
			</div>
		</div>
		<div class="fg">
			<button type="submit" class="btn"><i class="fa fa-sign-in"></i>Inloggen</button>
			
		</div>
	{{ Form::close() }}
@stop