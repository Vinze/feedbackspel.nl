@extends('layout.base')
@section('content')
	<h1>Users</h1>
	{{ HTML::flash() }}
	<a href="{{ url('logout') }}">Uitloggen</a>
@stop