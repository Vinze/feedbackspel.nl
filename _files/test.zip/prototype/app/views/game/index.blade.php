@extends('layout.base')
@section('content')
	<h1>Game</h1>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, unde voluptatum est minus nobis a odio omnis harum mollitia. Optio, quas, saepe nemo dolorem repudiandae atque nobis totam ipsam dicta.</p>
	<ul>
		<li>dsaksdah</li>
		<li>dsaksdah</li>
		<li>dsaksdah</li>
	</ul>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, unde voluptatum est minus nobis a odio omnis harum mollitia. Optio, quas, saepe nemo dolorem repudiandae atque nobis totam ipsam dicta.</p>
	<h2>Nog meer tekst..</h2>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, unde voluptatum est minus nobis a odio omnis harum mollitia. Optio, quas, saepe nemo dolorem repudiandae atque nobis totam ipsam dicta.</p>
	<p>
		<a href="{{ url('game/new/'.$id) }}" class="btn"><i class="fa fa-gamepad"></i> Nieuw spel starten</a>
	</p>
@stop