@extends('layout.mobile')
@section('content')
	<h2>Welke kleur zie je?</h2>
	<ul id="colorpicker" style="display:none">
	</ul>
	{{ Form::open(array('id' => 'setname')) }}
		{{ Form::label('name', 'Voer je naam in:') }}<br>
		{{ Form::text('name') }}
	{{ Form::close() }}
@stop
@section('scripts')
	<script src="http://172.16.1.10:1337/socket.io/socket.io.js"></script>
	<script type="text/javascript">
		//var url = 'http://' + document.domain + ':1337';
		var socket = io.connect('http://172.16.1.10:1337/player');
		
		$('#setname').on('submit', function(e) {
			e.preventDefault();
			var name = $('#name').val();
			$('#colorpicker').show();
			$('#setname').hide();
			socket.emit('set name', name);
		});

		$('#colorpicker').on('click', 'a', function(e) {
			var color = $(this).data('color');
			socket.emit('color selected', color);
			console.log(color);
		});

		socket.on('update colors', function(colors) {
			$('#colorpicker').html('');
			setTimeout(function() {
				var html = '';
				$.each(colors, function (i, color) {
					html += [
						'<li style="background-color: ' + color + '">',
							'<a href="#" data-color="' + color + '"></a>',
						'</li>'
					].join('\n');
				});
				$('#colorpicker').html(html);
			}, 1000);
		});
		
	</script>
@stop