@extends('layout.base')
@section('content')
	<h1>Feedbackspel.nl</h1>
	<div class="row">
		<div class="col span-6">
			<h2>Selecteer de volgende kleur:</h2>
			<div id="color" style="width: 80%; height: 150px"></div>
		</div>
		<div class="col span-4 offset-2">
			<h2>Deelnemers:</h2>
			<ul id="players">
			</ul>
			<a href="#" id="reset-score">Reset scores</a>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col span-12">
			<h2>Meespelen?</h2>
			<p>Scan de onderstaande QR code!</p>
			<p><img src="{{ url('game/qrcode/'.$id) }}" alt=""></p>
			<p><small>
				Of ga naar:<br><a href="{{ url('game/play/'.$id) }}">.../game/play/{{ $id }}</a>
			</small></p>
		</div>
	</div>
@stop
@section('scripts')
	<script src="http://172.16.1.10:1337/socket.io/socket.io.js"></script>
	<script type="text/javascript">
	var socket = io.connect('http://172.16.1.10:1337/host');

	socket.on('winning color', function(color) {
		$('#color').css({'background-color': 'transparent'});
		setTimeout(function() {
			$('#color').css({'background-color': color});
		}, 1000);
	});

	socket.on('update players', function(players) {
		var html = '';
		$.each(players, function(id, player) {
			if (player.name) {
				html += '<li>' + player.name + ' (' + player.score + ' punten)</li>';
			}
		});
		$('#players').html(html);
	});

	$('#reset-score').on('click', function(e) {
		e.preventDefault();
		socket.emit('reset scores');
	});
	</script>
@stop