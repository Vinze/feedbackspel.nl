@extends('layout.base')
@section('head')
<style type="text/css">
	body {
		background-color: #e5e5e5;
	}
	#canvas {
		position: relative;
		box-shadow: 0 0 10px rgba(150, 150, 150, 0.5);
		cursor: default;
		margin-bottom: 20px;
		background-color: #fff;
	}
</style>
@stop
@section('content')
	<canvas id="canvas" width="768px" height="500px"></canvas>
	<a href="#" id="clear-points">Canvas legen</a>
@stop
@section('scripts')
	<script src="http://172.16.1.10:1337/socket.io/socket.io.js"></script>
	<script>
		var socket = io.connect('http://172.16.1.10:1337');

		var canvas = $('#canvas')[0];

		var ctx = canvas.getContext('2d');
		ctx.save();

		var randomColor = function() {
			var letters = '0123456789ABCDEF'.split('');
			var color = '#';
			for (var i = 0; i < 6; i++) {
				color += letters[Math.round(Math.random() * 15)];
			}
			return color;
		}

		var addPoint = function(point) {
			// Draw the point
			ctx.beginPath();
			ctx.arc(point.x, point.y, 10, 0, Math.PI * 2);

			// Set the fill
			ctx.fillStyle = point.color;
			ctx.fill();

			// Set the stroke
			ctx.strokeStyle = '#fff';
			ctx.stroke();

			// Reset the element
			ctx.restore();
		}

		var clearPoints = function() {
			// Clear the canvas
			ctx.clearRect (0, 0, canvas.width, canvas.height);

			// Reset the element
			ctx.restore();
		}

		socket.on('addPoint', function(point) {
			addPoint(point);
		});

		socket.on('clearPoints', function() {
			clearPoints();
		});

		$('#canvas').on('click', function(evt) {
			var point = {
				x: (evt.pageX - $(this).offset().left),
				y: (evt.pageY - $(this).offset().top),
				color: randomColor()
			}
			socket.emit('addPoint', point);
		});

		$('#clear-points').on('click', function(evt) {
			socket.emit('clearPoints');
			evt.preventDefault();
		});

		$(function() {
			// Fill the canvas with the saved points
			$.get(base_url + '/points.json', function(points) {
				$.each(points, function(i, point) {
					addPoint(point);
				});
			});
		});
	</script>
@stop