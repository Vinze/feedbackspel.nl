<?php
class Point extends BaseModel {

	protected $table = 'points';

	protected $fillable = array('x', 'y');

	public $timestamps = false;

}