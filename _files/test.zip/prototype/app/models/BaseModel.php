<?php
class BaseModel extends Eloquent {

	public static function boot() {
		parent::boot();

		// static::saving(function($model) {
		// 	if ($model->timestamps) {
		// 		if ( ! $model->exists ) $model->created_by = Auth::user()->initials;
		// 		$model->updated_by = Auth::user()->initials;
		// 	}
		// });

	}

}