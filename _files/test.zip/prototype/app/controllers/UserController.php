<?php
class UserController extends BaseController {

	public function getIndex() {
		return View::make('users.index');
	}

	public function getLogin() {
		return View::make('users.login');
	}

	public function postLogin() {
		$email = Input::get('email');
		$password = Input::get('password');
		$remember_me = Input::has('remember_me');

		if (Auth::attempt(array('email' => $email, 'password' => $password), $remember_me)) {
			return Redirect::to('users')->with('message', 'Je bent ingelogd!');
		} else {
			return Redirect::to('login')->with('error', 'E-mailadres/wachtwoord komen niet overeen!');
		}
	}

	public function getLogout() {
		Auth::logout();
	}
}