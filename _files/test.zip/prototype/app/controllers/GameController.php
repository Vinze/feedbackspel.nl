<?php
use Endroid\QrCode;

class GameController extends BaseController {

	public function getIndex() {
		$id = rand(1000, 9999);
		return View::make('game.index', compact('id'));
	}

	public function getHost($id) {
		return View::make('game.host', compact('id'));
	}

	public function getPlay($id) {
		return View::make('game.play', compact('id'));
	}

	public function getQrcode($id) {
		$qrCode = new Endroid\QrCode\QrCode();
		$qrCode->setText('http://172.16.1.10/afstuderen/prototype/public/game/play/'.$id);
		$qrCode->setSize(150);
		$qrCode->setPadding(0);
		header('Content-Type: image/png');
		$qrCode->render();
		die();
	}

}