<?php
function print_f($data) {
	echo '<pre>'.print_r($data, true).'</pre>';
}