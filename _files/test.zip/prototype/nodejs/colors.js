var io = require('socket.io').listen(1337);

var players = {};
var colors = [];
var winning = null;
var chars = '0123456789ABCDEF'.split('');

var updateColors = (function() {
	colors = [];
	for (var i = 0; i < 5; i++) {
		var color = '#';
		for (var c = 0; c < 6; c++) {
			color += chars[Math.round(Math.random() * 15)];
		}
		colors.push(color);
	}
	winning = colors[Math.floor((Math.random() * 5))];
	
	player.emit('update colors', colors);
	host.emit('winning color', winning);
});

var host = io.of('/host').on('connection', function(client) {
	client.emit('winning color', winning);
	client.emit('update players', players);
	client.on('reset scores', function() {
		for (var i = 0; i < players.length; i++) {
			console.log(players[i]);
		}
	});
});

var player = io.of('/player').on('connection', function(client) {

	players[client.id] = {
		name: null,
		score: 0
	};

	client.emit('update colors', colors);

	client.on('set name', function(name) {
		players[client.id].name = name;
		host.emit('update players', players);
	});

	client.on('color selected', function(color) {
		if (color == winning) {
			players[client.id].score++;
			updateColors();
		} else {
			players[client.id].score--;
		}
		host.emit('update players', players);
	});

	client.on('disconnect', function () {
		delete players[client.id];
		host.emit('update players', players);
	});
});

updateColors();

// var timer = setInterval(function() {
// 	updateColors();
// }, 10000);