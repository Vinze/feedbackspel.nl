var io = require('socket.io').listen(1337),
	mysql = require('mysql2');

var db = mysql.createConnection({
	user: 'root',
	password: 'usbw',
	database: 'afstuderen_prototype'
});

console.log('Server running at http://localhost:1337')

io.sockets.on('connection', function (socket) {
	socket.on('addPoint', function(point) {
		var values = [point.x, point.y, point.color];
		db.execute('INSERT INTO points (x, y, color) VALUES (?, ?, ?)', values, function(err, rows) {
			if (err) {
				console.log('Warning, an error has occured:')
				console.log(err);
			}
		});
		io.sockets.emit('addPoint', point);
	});

	socket.on('clearPoints', function(point) {
		db.query('TRUNCATE points', function(err, rows) {
			if (err) {
				console.log('Warning, an error has occured:')
				console.log(err);
			}
		});
		io.sockets.emit('clearPoints', point);
	});
});