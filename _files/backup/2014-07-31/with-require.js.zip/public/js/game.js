require(['angular'], function(angular) {
	var app = angular.module('feedbackspel', []);
	app.controller('GameCtrl', function($scope) {
		$scope.players = [
			{ 'id': 1, 'name': 'George Clooney' },
			{ 'id': 2, 'name': 'Emma Watson' },
			{ 'id': 3, 'name': 'Morgan Freeman' },
			{ 'id': 4, 'name': 'Zooey Deschanel' },
			{ 'id': 5, 'name': 'Gerard Butler' }
		];

		$scope.select = function(player) {
			player.selected = !player.selected;
		}
	});
});